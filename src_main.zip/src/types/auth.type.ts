export interface RequestLogin {
    username: string;
    password: string;
}