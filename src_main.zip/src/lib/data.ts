// export const searchContent = {
//     feedbackDislike: {
//         incorrect: "The content is incorrect.",
//         outdated: "Old content, urgent update!",
//         dislike: "I don't like this content."
//     }
// }

export const searchContent = [
    { key: "incorrect", text: "ข้อมูลไม่ถูกต้อง" },
    { key: "not_complete", text: "คำตอบยังไม่สมบูรณ์" },
    { key: "no_answer", text: "ไม่มีคำตอบ" },
    { key: "other", text: "อื่น ๆ" },
]

export const assistantList = [
    { key: "as_1", text: "IT10 Service desk assistant-new" },
    { key: "as_2", text: "IT10 Service desk assistant" },
    { key: "as_3", text: "MiRai Service desk assistant-new" },
    { key: "as_4", text: "MiRai Service desk assistant" },
    { key: "as_5", text: "PC service assistant" },
    { key: "as_6", text: "Infra service assistant" },
    { key: "as_7", text: "GIS assistant" },
    { key: "as_8", text: "Generic AI (4.0)" },
]